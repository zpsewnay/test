package com.packt.webstore.controller;

import java.io.File;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import com.packt.webstore.services.ProductService;
import com.packt.webstore.services.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.StringUtils;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.MatrixVariable;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.packt.webstore.domain.Product;
import com.packt.webstore.exception.NoProductsFoundUnderCategoryException;
import com.packt.webstore.exception.ProductNotFoundException;
import com.packt.webstore.validator.ProductValidator;

@Controller
@RequestMapping("market")
public class ProductController {

    @Autowired
    private ProductService productService;

    @Autowired
    private ProductValidator productValidator;

    /**
     * P. 148
     * Chapter 5 :
     * http://localhost:8080/webstore/market/products
     * Product -> Detail
     *
     * @param model
     * @return
     */
    @RequestMapping("/products")
    public String list(Model model) {
        List<Product> productList = productService.getAllProducts();
        System.err.println("list productList ==>" + productList.size());
        model.addAttribute("products", productList);
        return "products";
    }

    /**
     * http://localhost:8080/webstore/market/products/Smartphone
     * @param model
     * @param category
     * @return String
     */
    @RequestMapping("/products/{category}")
    public String getProductsByCategory(Model model, @PathVariable("category") String category) {
        List<Product> productList = productService.getProductsByCategory(category);
        System.err.println("getProductsByCategory productList ==>" + productList.size());
        if (productList == null || productList.isEmpty()) {
            throw new NoProductsFoundUnderCategoryException();
        }

        model.addAttribute("products", productList);
        return "products";
    }

    /**
     * Detail 進入口
     * http://localhost:8080/webstore/market/product?id=P1234
     * @param productId
     * @param model
     * @return String
     */
    @RequestMapping("/product")
    public String getProductById(@RequestParam("id") String productId, Model model) {
        Product specificProduct = productService.getProductById(productId);
        System.err.println("getProductsByCategory specificProduct specificProduct ==>" + specificProduct);
        model.addAttribute("product", specificProduct);
        return "product";
    }

    /**
     *
     * http://localhost:8080/webstore/market/update/stock
     * @param model
     * @return String
     */
    @RequestMapping("/update/stock")
    public String updateStock(Model model) {
        productService.updateAllStock();
        return "redirect:/market/products";
    }

    @RequestMapping("/products/filter/{params}")
    public String getProductsByFilter(@MatrixVariable(pathVar = "params") Map<String, List<String>> filterParams, Model model) {
        model.addAttribute("products", productService.getProductsByFilter(filterParams));
        return "products";
    }

    /**
     * Upload File Entry
     * http://localhost:8080/webstore/market/products/add
     * @param model
     * @return String
     */
    @RequestMapping(value = "/products/add", method = RequestMethod.GET)
    public String getAddNewProductForm(Model model) {
        Product newProduct = new Product();
        model.addAttribute("newProduct", newProduct);
        return "addProduct";
    }

    /**
     * Upload File Form submit
     * http://localhost:8080/webstore/market/products/add
     * @param newProduct
     * @param result
     * @param request
     * @return String
     */
    @RequestMapping(value = "/products/add", method = RequestMethod.POST)
    public String processAddNewProductForm(@ModelAttribute("newProduct") @Valid Product newProduct,
                                           BindingResult result,
                                           HttpServletRequest request) {

        if (result.hasErrors()) {
            return "addProduct";
        }

        String[] suppressedFields = result.getSuppressedFields();
        if (suppressedFields.length > 0) {
            throw new RuntimeException("Attempting to bind disallowed fields: " + StringUtils.arrayToCommaDelimitedString(suppressedFields));
        }

        MultipartFile productImage = newProduct.getProductImage();
        System.err.println("productImage ==>" + productImage);
        String rootDirectory = request.getSession().getServletContext().getRealPath("/");

        if (productImage != null && !productImage.isEmpty()) {
            try {
                File saveFile = new File(rootDirectory + "resources/images/" + newProduct.getProductId() + ".png");
                System.err.println("saveFile ==>" + saveFile.toString());
                productImage.transferTo(saveFile);
            } catch (Exception e) {
                throw new RuntimeException("Product Image saving failed", e);
            }
        }


        productService.addProduct(newProduct);
        return "redirect:/market/products";
    }

    /**
     * Validator
     * @param binder
     */
    @InitBinder
    public void initialiseBinder(WebDataBinder binder) {
        binder.setValidator(productValidator);
        binder.setAllowedFields("productId",
                "name",
                "unitPrice",
                "description",
                "manufacturer",
                "category",
                "unitsInStock",
                "condition",
                "productImage",
                "language");
    }

    /**
     * P.181
     * Chapter 6 :
     * Error Redirect Interceptor
     * http://localhost:8080/webstore/market/products/specialOffer?pro mo=offer
     * @return String
     */
    @RequestMapping("/products/invalidPromoCode")
    public String invalidPromoCode() {
        return "invalidPromoCode";
    }

    /**
     * P.181
     * Chapter 6 :
     * Error Redirect Interceptor
     * http://localhost:8080/webstore/market/products/specialOffer?pro mo=offer
     * @param req
     * @param exception
     * @return ModelAndView
     */
    @ExceptionHandler(ProductNotFoundException.class)
    public ModelAndView handleError(HttpServletRequest req, ProductNotFoundException exception) {
        ModelAndView mav = new ModelAndView();
        mav.addObject("invalidProductId", exception.getProductId());
        mav.addObject("exception", exception);
        mav.addObject("url", req.getRequestURL() + "?" + req.getQueryString());
        mav.setViewName("productNotFound");
        return mav;
    }

}
