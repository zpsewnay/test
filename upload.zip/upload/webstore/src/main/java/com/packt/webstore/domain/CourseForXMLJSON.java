package com.packt.webstore.domain;

import javax.xml.bind.annotation.XmlRootElement;
import java.util.Date;

@XmlRootElement
public class CourseForXMLJSON {

    public void setId(Integer id) {
        this.id = id;
    }

    private Integer id;

    public void setName(String name) {
        this.name = name;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    private String name;
    private Date date;

    public CourseForXMLJSON() {
    }

    public CourseForXMLJSON(Integer id, String name, Date date) {
        this.id = id;
        this.name = name;
        this.date = date;
    }

    public Integer getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public Date getDate() {
        return date;
    }
}
