package com.packt.webstore.controller;

import com.packt.webstore.domain.CourseForXMLJSON;
import org.springframework.aop.framework.ProxyFactory;
import org.springframework.aop.framework.ProxyFactoryBean;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;

@Controller
@RequestMapping("/")
public class DownloadController {

    /**
     * PDF Download By AbstractPdfView
     * URL : http://localhost:8080/webstore/downloadPDF
     *
     * @param request
     * @return ModelAndView
     */
    @RequestMapping(value = "/downloadPDF", method = RequestMethod.GET)
    public ModelAndView greeting(HttpServletRequest request,
                                 HttpServletResponse response) {

        //ProxyFactoryBean factoryBean = new ProxyFactoryBean();
        //factoryBean.setProxyTargetClass(true);
        //factoryBean.setFrozen(true);
        //factoryBean.setOptimize(true);
        //
        //ProxyFactory proxyFactory = new ProxyFactory();
        //proxyFactory.setProxyTargetClass(true);
        //proxyFactory.setFrozen(true);
        //proxyFactory.setOptimize(true);

        //dummy data
        Map<String, String> revenueData = new HashMap<String, String>();
        revenueData.put("1/20/2010", "$100,000");
        revenueData.put("1/21/2010", "$200,000");
        revenueData.put("1/22/2010", "$300,000");
        revenueData.put("1/23/2010", "$400,000");
        revenueData.put("1/24/2010", "$500,000");
        return new ModelAndView("PdfRevenueSummary", "revenueData", revenueData);
    }


    /**
     * EXCEL download By AbstractXlsView
     * URL : http://localhost:8080/webstore/downloadEXCEL
     *
     * @return ModelAndView
     */
    @RequestMapping(value = "/downloadEXCEL", method = RequestMethod.GET)
    public ModelAndView getDocuments() {
        List<CourseForXMLJSON> documents = Arrays.asList(
                new CourseForXMLJSON(1, "Spring MVC Xls View", new Date()),
                new CourseForXMLJSON(2, "Spring MVC Xlsx View", new Date()),
                new CourseForXMLJSON(3, "Spring MVC XlsxStreaming View", new Date())
        );
        return new ModelAndView("XlsView", "courses", documents);
    }


    /**
     * Download File Path
     */
    private static final String FILE_PATH = "/Users/sunjiancheng/Desktop/Spring MVC.pdf";


    /**
     * Using ResponseEntity<InputStreamResource>
     * URL : http://localhost:8080/webstore/download1
     * reference : https://www.boraji.com/spring-mvc-4-file-download-example
     *
     * @return ResponseEntity<InputStreamResource>
     * @throws IOException
     */
    @GetMapping("/download1")
    public ResponseEntity<InputStreamResource> downloadFile1() throws IOException {

        File file = new File(FILE_PATH);
        InputStreamResource resource = new InputStreamResource(new FileInputStream(file));

        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION,
                        "attachment;filename=" + file.getName())
                .contentType(MediaType.APPLICATION_PDF).contentLength(file.length())
                .body(resource);
    }

    /**
     * Using ResponseEntity<ByteArrayResource>
     * URL : http://localhost:8080/webstore/download2
     * reference : https://www.boraji.com/spring-mvc-4-file-download-example
     *
     * @return ResponseEntity<ByteArrayResource>
     * @throws IOException
     */
    @GetMapping("/download2")
    public ResponseEntity<ByteArrayResource> downloadFile2() throws IOException {

        Path path = Paths.get(FILE_PATH);
        byte[] data = Files.readAllBytes(path);
        ByteArrayResource resource = new ByteArrayResource(data);

        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION,
                        "attachment;filename=" + path.getFileName().toString())
                .contentType(MediaType.APPLICATION_PDF).contentLength(data.length)
                .body(resource);
    }

    /**
     * Using HttpServletResponse
     * URL : http://localhost:8080/webstore/download3
     * reference : https://www.boraji.com/spring-mvc-4-file-download-example
     *
     * @param response
     * @throws IOException
     */
    @GetMapping("/download3")
    public void downloadFile3(HttpServletResponse response) throws IOException {
        File file = new File(FILE_PATH);

        response.setContentType("application/pdf");
        response.setHeader("Content-Disposition", "attachment;filename=" + file.getName());
        BufferedInputStream inStrem = new BufferedInputStream(new FileInputStream(file));
        BufferedOutputStream outStream = new BufferedOutputStream(response.getOutputStream());

        byte[] buffer = new byte[1024];
        int bytesRead = 0;
        while ((bytesRead = inStrem.read(buffer)) != -1) {
            outStream.write(buffer, 0, bytesRead);
        }
        outStream.flush();
        inStrem.close();
    }


}
