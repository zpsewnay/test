package com.packt.webstore.domain;

public interface Job {
    public void describe();
}
