package com.packt.webstore.domain;

import org.apache.ibatis.type.Alias;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import java.io.Serializable;
import java.util.logging.Logger;

public class LifeTestBean implements Serializable {
    private static final long serialVersionUID = 1L;

    private static Logger logger = Logger.getLogger("LifeTestBean");

    public LifeTestBean() {
    }

    @PostConstruct
    public void constructDone() {
        logger.info("LifeTestBean constructed done !");
    }

    @PreDestroy
    public void preDestroy() {
        logger.info("LifeTestBean constructed done !");
    }

}
