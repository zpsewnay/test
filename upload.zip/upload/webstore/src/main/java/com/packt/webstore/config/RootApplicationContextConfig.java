package com.packt.webstore.config;

import com.packt.webstore.dataSource.XBasicDataSource;
import org.apache.commons.dbcp.BasicDataSource;
import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.transaction.PlatformTransactionManager;

import javax.sql.DataSource;

@Configuration
@ComponentScan("com.packt.webstore")
@MapperScan("com.packt.webstore.mappers")
//@PropertySource({"classpath:mysql.properties"})
@PropertySource({"classpath:oracle.properties"})
public class RootApplicationContextConfig {

    //   @Bean
//   public DataSource dataSourceForEmbeddedDB() {
//      EmbeddedDatabaseBuilder builder = new EmbeddedDatabaseBuilder();
//      EmbeddedDatabase db = builder.setType(EmbeddedDatabaseType.HSQL)
//                           .addScript("db/sql/create-table.sql")
//                           .addScript("db/sql/insert-data.sql")
//                           .build();
//      return db;
//   }
//

    @Value("${jdbc.driverClassName}")
    private String driverClassName;

    @Value("${jdbc.url}")
    private String jdbcUrl;

    @Value("${jdbc.username}")
    private String user;

    @Value("${jdbc.password}")
    private String password;

    @Bean
    public NamedParameterJdbcTemplate getJdbcTemplate() {
        return new NamedParameterJdbcTemplate(dataSource());
    }

    @Bean
    public static PropertySourcesPlaceholderConfigurer propertySourcesPlaceholderConfigurer() {
        return new PropertySourcesPlaceholderConfigurer();
    }

    @Bean
    public DataSource dataSource() {
//        XBasicDataSource dataSource = new XBasicDataSource();
//        dataSource.setDriverClassName(driverClassName);
//        dataSource.setUrl(jdbcUrl);
//        dataSource.setUsername(user);
//        dataSource.setPassword(password);
//        return dataSource;

        BasicDataSource dataSource = new BasicDataSource();
        dataSource.setDriverClassName(driverClassName);
        dataSource.setUrl(jdbcUrl);
        dataSource.setUsername(user);
        dataSource.setPassword(password);
        return dataSource;

    }

    @Bean
    public SqlSessionFactory sqlSessionFactory() throws Exception {
        SqlSessionFactoryBean factoryBean = new SqlSessionFactoryBean();
        factoryBean.setDataSource(dataSource());
        factoryBean.setTypeAliasesPackage("com.packt.webstore.domain");
        //factoryBean.setMapperLocations(
        //        new PathMatchingResourcePatternResolver().getResources("classpath:com/packt/webstore/mappers/*.xml"));
        return factoryBean.getObject();
    }

    @Bean
    public PlatformTransactionManager transactionManager() {
        return new DataSourceTransactionManager(dataSource());
    }


}
