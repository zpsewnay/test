package com.packt.webstore.domain.repository.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import com.packt.webstore.domain.Product;
import com.packt.webstore.domain.repository.ProductRepository;
import com.packt.webstore.exception.ProductNotFoundException;

/**
 * Implementation For ProductRepository @Repository
 */
@Repository
public class InMemoryProductRepository implements ProductRepository {

    /**
     * NamedParameterJdbcTemplate
     */
    @Autowired
    private NamedParameterJdbcTemplate jdbcTemplate;

    /**
     * Mapper For Product
     */
    private static final class ProductMapper implements RowMapper<Product> {
        public Product mapRow(ResultSet rs, int rowNum) throws SQLException {
            Product product = new Product();
            product.setProductId(rs.getString("ID"));
            product.setName(rs.getString("NAME"));
            product.setDescription(rs.getString("DESCRIPTION"));
            product.setUnitPrice(rs.getBigDecimal("UNIT_PRICE"));
            product.setManufacturer(rs.getString("MANUFACTURER"));
            product.setCategory(rs.getString("CATEGORY"));
            product.setCondition(rs.getString("CONDITION"));
            product.setUnitsInStock(rs.getLong("UNITS_IN_STOCK"));
            product.setUnitsInOrder(rs.getLong("UNITS_IN_ORDER"));
            product.setDiscontinued(rs.getBoolean("DISCONTINUED"));
            return product;
        }
    }

    /**
     * 取得所有Product Info
     * @return List<Product>
     */
    @Override
    public List<Product> getAllProducts() {
        Map<String, Object> params = new HashMap<String, Object>();
        List<Product> result = jdbcTemplate.query("SELECT * FROM test.products", params, new ProductMapper());
        System.err.println("getAllProducts returnList ==>" + result.size());
        return result;
    }

    /**
     * 查詢特定類目的 product
     * @param category
     * @return List<Product>
     */
    @Override
    public List<Product> getProductsByCategory(String category) {
        String SQL = "SELECT * FROM PRODUCTS WHERE CATEGORY = :category";
        Map<String, Object> params = new HashMap<String, Object>();
        params.put("category", category);
        return jdbcTemplate.query(SQL, params, new ProductMapper());
    }

    /**
     * 依據ID查詢特定 Product
     * @param productID
     * @return Product
     */
    @Override
    public Product getProductById(String productID) {
        String SQL = "SELECT * FROM PRODUCTS WHERE ID = :id";
        Map<String, Object> params = new HashMap<>();
        params.put("id", productID);

        try {
            return jdbcTemplate.queryForObject(SQL, params, new ProductMapper());
        } catch (DataAccessException e) {
            throw new ProductNotFoundException(productID);
        }
    }


    @Override
    public void updateStock(String productId, long noOfUnits) {
        String SQL = "UPDATE PRODUCTS SET UNITS_IN_STOCK = :unitsInStock WHERE ID = :id";
        Map<String, Object> params = new HashMap<>();
        params.put("unitsInStock", noOfUnits);
        params.put("id", productId);
        jdbcTemplate.update(SQL, params);
    }


    @Override
    public List<Product> getProductsByFilter(Map<String, List<String>> filterParams) {
        String SQL = "SELECT * FROM PRODUCTS WHERE CATEGORY IN ( :categories ) AND MANUFACTURER IN ( :brands)";
        return jdbcTemplate.query(SQL, filterParams, new ProductMapper());
    }

    @Override
    public void addProduct(Product product) {
        String SQL = "INSERT INTO PRODUCTS (" + "\r\n" +
                "ID, " + "\r\n" +
                "NAME," + "\r\n" +
                "DESCRIPTION," + "\r\n" +
                "UNIT_PRICE," + "\r\n" +
                "MANUFACTURER," + "\r\n" +
                "CATEGORY," + "\r\n" +
                "`CONDITION`," + "\r\n" +
                "UNITS_IN_STOCK," + "\r\n" +
                "UNITS_IN_ORDER," + "\r\n" +
                "DISCONTINUED) " + "\r\n" +
                "VALUES (" + "\r\n" +
                ":id, " + "\r\n" +
                ":name, " + "\r\n" +
                ":desc, " + "\r\n" +
                ":price, " + "\r\n" +
                ":manufacturer, " + "\r\n" +
                ":category, " + "\r\n" +
                ":condition, " + "\r\n" +
                ":inStock, " + "\r\n" +
                ":inOrder, " + "\r\n" +
                ":discontinued" + "\r\n" +
                ")";

        System.err.println("product.getProductId() ==>" + product.getProductId());
        System.err.println("product.getName() ==>" + product.getName());
        System.err.println("product.getDescription() ==>" + product.getDescription());
        System.err.println("product.getUnitPrice() ==>" + product.getUnitPrice());

        System.err.println("product.getManufacturer() ==>" + product.getManufacturer());
        System.err.println("product.getCategory() ==>" + product.getCategory());
        System.err.println("product.getCondition() ==>" + product.getCondition());
        System.err.println("product.getUnitsInStock() ==>" + product.getUnitsInStock());

        System.err.println("product.getUnitsInOrder() ==>" + product.getUnitsInOrder());
        System.err.println("product.isDiscontinued() ==>" + product.isDiscontinued());

        Map<String, Object> params = new HashMap<>();
        params.put("id", product.getProductId());
        params.put("name", product.getName());
        params.put("desc", product.getDescription());
        params.put("price", product.getUnitPrice());

        params.put("manufacturer", product.getManufacturer());
        params.put("category", product.getCategory());
        params.put("condition", product.getCondition());
        params.put("inStock", product.getUnitsInStock());

        params.put("inOrder", product.getUnitsInOrder());
        if(product.isDiscontinued()) {
            params.put("discontinued", "1");
        }else {
            params.put("discontinued", "0");
        }


        jdbcTemplate.update(SQL, params);
    }


}
