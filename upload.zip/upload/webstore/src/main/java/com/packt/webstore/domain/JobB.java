package com.packt.webstore.domain;

import org.springframework.stereotype.Component;

import java.util.logging.Logger;

@Component("JobB")
public class JobB implements Job {

    private static Logger logger = Logger.getLogger("JobB");

    @Override
    public void describe() {
        logger.info("Job B is a good job !");
    }
}
