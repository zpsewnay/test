package com.packt.webstore.services;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.packt.webstore.domain.Product;
import com.packt.webstore.domain.repository.ProductRepository;
import org.springframework.transaction.annotation.Transactional;

@Service
public class ProductServiceImpl implements ProductService {

    /*
     * @Repository For ProductService
     */
    @Autowired
    private ProductRepository productRepository;

    @Override
    @Transactional()
    public void updateAllStock() {
        List<Product> allProducts = productRepository.getAllProducts();

        for (Product product : allProducts) {
            if (product.getUnitsInStock() < 500)
                productRepository.updateStock(product.getProductId(), product.getUnitsInStock() + 1000);
        }
    }

    /**
     * 取得所有Product Info
     * @return List<Product>
     */
    @Override
    public List<Product> getAllProducts() {
        return productRepository.getAllProducts();
    }

    /**
     * 查詢特定類目的 Product
     * @param category
     * @return List<Product>
     */
    public List<Product> getProductsByCategory(String category) {
        return productRepository.getProductsByCategory(category);
    }

    /**
     * 依據ID查詢特定 Product
     * @param productID
     * @return Product
     */
    @Override
    public Product getProductById(String productID) {
        return productRepository.getProductById(productID);
    }

    public List<Product> getProductsByFilter(Map<String, List<String>> filterParams) {
        return productRepository.getProductsByFilter(filterParams);
    }

    @Override
    public void addProduct(Product product) {
        productRepository.addProduct(product);
    }

}
