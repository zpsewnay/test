package com.packt.webstore.controller;

import com.packt.webstore.domain.CourseForXMLJSON;
import com.packt.webstore.domain.Job;
import com.packt.webstore.domain.LifeTestBean;
import com.packt.webstore.domain.Student;
import com.packt.webstore.services.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.*;
import java.util.logging.Logger;

@Controller
@RequestMapping("/")
public class JSONAndXMLController {

//	@Autowired
//	private LifeTestBean testBean;


    //@Override
    //public void configureMessageConverters(List<HttpMessageConverter<?>> converters) {
    //	Jackson2ObjectMapperBuilder builder = new Jackson2ObjectMapperBuilder()
    //			.indentOutput(true)
    //			.dateFormat(new SimpleDateFormat("yyyy-MM-dd"))
    //			.modulesToInstall(new ParameterNamesModule());
    //	converters.add(new MappingJackson2HttpMessageConverter(builder.build()));
    //	converters.add(new MappingJackson2XmlHttpMessageConverter(builder.createXmlMapper(true).build()));
    //}

    private static Logger logger = Logger.getLogger("JSONAndXMLController");

    @Autowired
    private StudentService useStudentService;

    @Autowired
    @Qualifier("JobB")
    private Job testJob;

    public JSONAndXMLController() {
    }


//	private StudentService useStudentService;
//	private Job testJob;
//
//	public JSONAndXMLController(
//			@Autowired
//					StudentService useStudentService,
//			@Autowired @Qualifier("JobB")
//					Job testJob) {
//		logger.info("JSONAndXMLController(StudentService useStudentService, Job testJob) is called !");
//		this.useStudentService = useStudentService;
//		this.testJob = testJob;
//	}


    /**
     * Return JSON format data
     * URL : http://localhost:8080/webstore/jsonformat
     *
     * @param model
     * @return List<Course>
     */
    @RequestMapping(value = "/jsonformat", produces = "application/json")
    public @ResponseBody
    List<CourseForXMLJSON> restDCNListJson(Model model, @RequestParam("data") String msg) {

        System.err.println("msg ==>" + msg);

        return getList();
    }

    /**
     * Return JSON format data
     * URL : http://localhost:8080/webstore/jQueryTest
     *
     * @param model
     * @return List<Course>
     */
    @RequestMapping(value = "/jQueryTest", produces = "application/json")
    public @ResponseBody
    String jQueryTest(Model model) {
        return "test";
    }

    /**
     * Return XML format data
     * URL : http://localhost:8080/webstore/xmlformat
     *
     * @param model
     * @return List<Course>
     */
    @RequestMapping(value = "/xmlformat", produces = "application/xml")
    public @ResponseBody
    List<CourseForXMLJSON> restDCNListXml(Model model) {
        return getList();
    }

    /**
     * MyBatis Interation Test
     * URL : http://localhost:8080/webstore/mybatis
     *
     * @param model
     * @return Student
     */
    @RequestMapping(value = "/mybatis", produces = "application/json")
    //@RequestMapping(value="/mybatis")
    public @ResponseBody
    Student mybatisJSON(Model model) {
        Student student = useStudentService.findStudentWithAddressById(2);
        return student;
    }


    /**
     * MyBatis Interation Test
     * URL : http://localhost:8080/webstore/mybatis2
     *
     * @param model
     * @return Student
     */
    @RequestMapping(value = "/mybatis2", produces = "application/json")
    public @ResponseBody
    List<Student> mybatisJSON2(Model model) {
        return useStudentService.findAllStudents();
    }


    /**
     * LifeTestBean Test
     * URL : http://localhost:8080/webstore/testBean
     *
     * @param testBean
     * @param model
     * @return Student
     */
    @RequestMapping(value = "/testBean", produces = "application/json")
    public @ResponseBody
    List<Student> mybatisJSON2(@Autowired LifeTestBean testBean, Model model) {
        return useStudentService.findAllStudents();
    }

    /**
     * @param model
     * @return Student
     * @Qualifier Test
     * URL : http://localhost:8080/webstore/testJob
     */
    @RequestMapping(value = "/testJob", produces = "application/json")
    public @ResponseBody
    List<Student> qualifierTest(Model model) {
        testJob.describe();
        return useStudentService.findAllStudents();
    }


    private List<CourseForXMLJSON> getList() {
        // java.util.Date --> java.util.Calendar
        java.util.Date now = new java.util.Date();
        java.util.Calendar calendar = java.util.Calendar.getInstance();
        calendar.setTime(now);

        // java.util.Calendar --> java.util.Date
        java.util.Date utilDate = java.util.Calendar.getInstance().getTime();

        CourseForXMLJSON newCourse = new CourseForXMLJSON();
        newCourse.setId(1);
        newCourse.setName("Java");
        newCourse.setDate(utilDate);

        List<CourseForXMLJSON> returnList = new ArrayList<CourseForXMLJSON>();
        returnList.add(newCourse);
        return returnList;
    }


}
