package com.packt.webstore.domain;

import org.springframework.stereotype.Component;

import java.util.logging.Logger;

@Component("JobA")
public class JobA implements Job {

    private static Logger logger = Logger.getLogger("JobA");

    @Override
    public void describe() {
        logger.info("Job A is a good job !");
    }
}
