INSERT INTO test.PRODUCTS VALUES ('P1234', 'iPhone 6s',
                      'Apple iPhone 6s smartphone with 4.00-inch 640x1136 display and 8-megapixel rear camera','500','Apple','Smartphone','New',450,0,false);

INSERT INTO test.PRODUCTS VALUES ('P1235', 'Dell Inspiron',
                     'Dell Inspiron 14-inch Laptop (Black) with 3rd Generation Intel Core processors',
                     700,'Dell','Laptop','New',1000,0,false);

INSERT INTO test.PRODUCTS VALUES ('P1236', 'Nexus 7',
                     'Google Nexus 7 is the lightest 7 inch tablet With a quad-core Qualcomm Snapdragon� S4 Pro processor',
                      300,'Google','Tablet','New',1000,0,false);



#### ORACLE

INSERT INTO test.PRODUCTS(
ID, NAME, DESCRIPTION, UNIT_PRICE, MANUFACTURER,
CATEGORY, CONDITION, UNITS_IN_STOCK, UNITS_IN_ORDER, DISCONTINUED)
VALUES ('P1234',
        'iPhone 6s',
        'Apple iPhone 6s smartphone with 4.00-inch 640x1136 display and 8-megapixel rear camera',
        '500',
        'Apple',
        'Smartphone',
        'New',
        450,
        0,
        'false');

INSERT INTO test.PRODUCTS(
ID, NAME, DESCRIPTION, UNIT_PRICE, MANUFACTURER,
CATEGORY, CONDITION, UNITS_IN_STOCK, UNITS_IN_ORDER, DISCONTINUED)
VALUES ('P1235', 'Dell Inspiron',
                     'Dell Inspiron 14-inch Laptop (Black) with 3rd Generation Intel Core processors',
                     700,'Dell','Laptop','New',1000,0,'false');

INSERT INTO test.PRODUCTS(
ID, NAME, DESCRIPTION, UNIT_PRICE, MANUFACTURER,
CATEGORY, CONDITION, UNITS_IN_STOCK, UNITS_IN_ORDER, DISCONTINUED)
VALUES ('P1236', 'Nexus 7',
                     'Google Nexus 7 is the lightest 7 inch tablet With a quad-core Qualcomm Snapdragon� S4 Pro processor',
                      300,'Google','Tablet','New',1000,0,'false');